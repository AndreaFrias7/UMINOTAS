package com.example.uminotas.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.uminotas.ui.theme.*

@Composable
fun HomeScreen(navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(White80)
    ) {
        // Letras verticales
        Column(
            verticalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 8.dp)
        ) {
            "NOTES".forEach { char ->
                Text(
                    text = char.toString(),
                    fontSize = 36.sp,
                    color = Navy,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Serif
                )
            }
        }

        // Círculos decorativos
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 24.dp)
        ) {
            CircleDecoration(Purple40)
            CircleDecoration(Pink40)
            CircleDecoration(Purple40)
        }

        // Botón de tutorial
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.align(Alignment.Center)
        ) {
            Text("Tutorial", fontSize = 16.sp, color = Black80)
            IconButton(
                onClick = { navController.navigate("tutorial") },
                modifier = Modifier
                    .size(80.dp)
                    .background(Navy, RoundedCornerShape(16.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Tutorial",
                    tint = White80,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        // Icono inferior
        IconButton(
            onClick = { /* Acción adicional */ },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Volver",
                tint = Navy
            )
        }
    }
}

@Composable
fun CircleDecoration(color: androidx.compose.ui.graphics.Color) {
    Box(
        modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(color)
    )
}
