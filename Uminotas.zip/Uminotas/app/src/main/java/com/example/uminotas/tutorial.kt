package com.example.uminotas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.uminotas.ui.theme.White80
import com.example.uminotas.ui.theme.Navy

@Composable
fun TutorialScreen(navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(White80),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "Aquí va el contenido del tutorial.",
            fontSize = 20.sp,
            color = Navy
        )
    }
}
