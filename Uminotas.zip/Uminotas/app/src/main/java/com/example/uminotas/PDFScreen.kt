package com.example.uminotas

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun PDFScreen(navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF3E0)) // fondo suave
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.align(Alignment.TopCenter),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Notas para exportar en PDF", fontSize = 22.sp, color = Color.DarkGray)
            Spacer(modifier = Modifier.height(12.dp))
            Text("Aquí aparecerán las notas listas para exportar.", fontSize = 16.sp)
        }

        Text(
            text = "⬅️ Volver",
            fontSize = 20.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .clickable { navController.navigate("home") }
                .padding(16.dp),
            color = Color(0xFF6A1B9A)
        )
    }
}
