package com.example.uminotas

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.example.uminotas.ui.theme.Purple80

@Composable
fun VoiceNoteScreen(noteTitle: String, navController: NavController) {
    var text by remember { mutableStateOf("") }
    val context = LocalContext.current

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText =
                result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.get(0)
            text = spokenText ?: ""
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            startVoiceRecognition(context, speechLauncher)
        } else {
            text = "Permiso de micrófono denegado"
        }
    }

    fun requestPermissionAndStart() {
        val permissionCheck =
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            startVoiceRecognition(context, speechLauncher)
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Si se trata de una nueva nota, guardar al volver
    LaunchedEffect(text) {
        if (text.isNotBlank() && noteTitle == "Nueva nota") {
            navController.previousBackStackEntry
                ?.savedStateHandle
                ?.set("nuevaNota", text)
            navController.popBackStack()
        }
    }

    // UI
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFFFF3E0))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(noteTitle, fontSize = 28.sp, color = Color.DarkGray)

            Spacer(modifier = Modifier.height(24.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Transcripción de voz") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            )

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = { requestPermissionAndStart() },
                colors = ButtonDefaults.buttonColors(containerColor = Purple80)
            ) {
                Text("🎙️ Iniciar micrófono")
            }
        }

        Text(
            text = "⬅️",
            fontSize = 32.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
                .clickable {
                    navController.navigate("home")
                },
            color = Purple80
        )
    }
}

fun startVoiceRecognition(
    context: Context,
    launcher: ActivityResultLauncher<Intent>
) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) {
        return
    }

    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla ahora...")
    }

    launcher.launch(intent)
}
