package com.example.uminotas

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.compose.ui.tooling.preview.Preview
import com.example.uminotas.ui.theme.UMINOTASTheme

@Composable
fun HomeScreen(navController: NavController) {
    val notes = remember { mutableStateListOf("NOTA 1", "NOTA 2", "NOTA 3", "NOTA 4") }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F5FA))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            Text("NOTES", fontSize = 36.sp, color = Color(0xFF734F96))

            OutlinedTextField(
                value = TextFieldValue(""),
                onValueChange = {},
                label = { Text("Buscar") },
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(0.85f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            notes.chunked(2).forEach { rowNotes ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    rowNotes.forEach { note ->
                        NoteCard(note, navController)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { navController.navigate("pdf") },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB497D6)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .padding(horizontal = 16.dp)
            ) {
                Text("TUS PDF", color = Color.White)
            }
        }

        Text(
            text = "TUS PDF",
            fontSize = 20.sp,
            color = Color(0xFF734F96),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
                .clickable {
                    // Acción para abrir PDF
                }
        )
    }
}

@Composable
fun NoteCard(title: String, navController: NavController) {
    Card(
        modifier = Modifier
            .size(140.dp)
            .clickable {
                navController.navigate("voice/${title}")
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(text = title, color = Color(0xFF734F96), fontSize = 18.sp)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewHomeScreen() {
    UMINOTASTheme {
        HomeScreen(navController = rememberNavController())
    }
}
