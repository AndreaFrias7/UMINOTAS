package com.example.uminotas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import com.example.uminotas.ui.theme.UMINOTASTheme
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UMINOTASTheme {
                val navController = rememberNavController()
                Surface {
                    NavHost(navController = navController, startDestination = "main") {
                        composable("main") { MainScreen(navController = navController) }
                        composable("home") { HomeScreen(navController = navController) }
                        composable(
                            "voice/{noteTitle}",
                            arguments = listOf(navArgument("noteTitle") { type = NavType.StringType })
                        ) { backStackEntry ->
                            val noteTitle = backStackEntry.arguments?.getString("noteTitle") ?: "Sin título"
                            VoiceNoteScreen(noteTitle = noteTitle, navController = navController) }
                        composable("pdf") {
                            PDFScreen(navController)
                            NavHost(navController = navController, startDestination = "home") {
                                composable("home") { HomeScreen(navController) }
                                composable("voice/{noteTitle}") { backStackEntry ->
                                    val noteTitle = backStackEntry.arguments?.getString("noteTitle") ?: ""
                                    VoiceNoteScreen(noteTitle, navController)
                                }
                                composable("pdf") { PDFScreen(navController) } // <--- MUY IMPORTANTE
                            }

                        }
                            }

                        }

                    }
                }
            }
        }

